THANKS TO EVERYONE IN THIS PROJECT

Cobweb+ [V1.1] by NaiNonTheN00b1
https://www.planetminecraft.com/texture-pack/cobweb-v1-0-1-14-1-18/
This work is licensed under a ﻿﻿Creative Commons Attribution 4.0 International License.


Fancy Pocket Watch by sukuro120
https://www.planetminecraft.com/texture-pack/fancy-pocket-watch/


Whistle Pipe by Create
https://www.curseforge.com/minecraft/mc-mods/create


Mug Texture by yo314159at
https://modrinth.com/resourcepack/mug-buckets


Backpack model and texture by UltroGhast
https://www.planetminecraft.com/data-pack/backpacks-4834903/